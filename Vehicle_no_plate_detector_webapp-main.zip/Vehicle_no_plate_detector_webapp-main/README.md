# Vehicle_no_plate_detector_webapp
Here we have created an WebApp which will fetch Details about the vehicle, whose image is uploaded by user in webapp
Video link- https://www.youtube.com/watch?v=-inkRfnR99I
