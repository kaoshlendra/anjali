var i = 0;
var txt = 'Number Plate Details';
var speed = 50;

/*function typeWriter() {
  if (i < txt.length) {
    document.getElementById("demo").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}
*/
/*function lws() {

  responsiveVoice.speak("hello world", "UK English Male");
}
*/
/*Diplaying image*/
var loadFile = function(event) {
	var image = document.getElementById('output');
	image.src = URL.createObjectURL(event.target.files[0]);
};

 


 



